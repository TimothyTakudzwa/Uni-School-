<?php 
//database connection file in the php folder 
require 'connect2db.php';
//getting user input 
session_start(); 
unset ($_SESSION['error']);
$username = mysqli_real_escape_string($cxn, $_POST['username']);
$password = mysqli_real_escape_string($cxn, $_POST['password']);
$email = mysqli_real_escape_string($cxn, $_POST['email']);
$name = mysqli_real_escape_string($cxn, $_POST['name']);
$access = mysqli_real_escape_string($cxn, $_POST['access']);
$username = mysqli_real_escape_string($cxn, $_POST['username']);
// checking the user provided access code to identify the role of the user 
if ($access=="Admin123"){
    $role = "Admin";
    $x=0;
// updating database table with new informatopn
$sql="INSERT INTO users (username,password, email, name,role)
VALUES ('$username', '$password', '$email', '$name', '$role')";
    }
if ($access=="Lecturer123"){
    $role = "Lecturer";
    $x=0;
// updating database table with new informatopn
$sql="INSERT INTO users (username,password, email, name,role)
VALUES ('$username', '$password', '$email', '$name', '$role')";
    }
if ($access=="Student123"){
    $role = "Student";
      $x=0;
// updating database table with new informatopn
$sql="INSERT INTO users (username,password, email, name,role)
VALUES ('$username', '$password', '$email', '$name', '$role')";
    } 
else {
        $role ="Timmy";
        $x="1";
       
    }

        // x = 0 means that the user has been created succesfully 
		header ("Location: ../login.php?x=$x");

?>