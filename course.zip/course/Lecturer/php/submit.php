 <?php
 session_start();
                                    if (isset($_POST['description'])) {
                                        require 'connect2db.php';
                                     
                                        $description = mysqli_real_escape_string($cxn, $_POST['description']);
                                        $name = mysqli_real_escape_string($cxn, $_POST['name']);
                                        $topic = mysqli_real_escape_string($cxn, $_POST['topic']);
                                        $subject = mysqli_real_escape_string($cxn, $_POST['subject']);
                                        $level = mysqli_real_escape_string($cxn, $_POST['level']);
                                        $started_by = $_SESSION['name'];
                                        $status = "Open";
                                        
                                        
                                        $sql="INSERT INTO groupchats (description,name, topic, status,subject, started_by, level)
                                        VALUES ('$description', '$name', '$topic', '$status', '$subject', '$started_by', '$level')";
                                        $connection = mysqli_query($cxn, $sql);
                                        $id = $cxn->insert_id;

                                        if (!mysqli_query($connection)) {
                                        header ("Location:../group.php?x=1&id=$id");}
                                        }
                                       
                                ?>