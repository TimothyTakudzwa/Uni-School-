<?php
                        $con=mysqli_connect("localhost","root","","unischool");
                      
                        error_reporting(null);
                            $target_dir = "assets/";
                            $target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
                            $uploadOk = 1;

                            $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
                            // Check if image file is a actual image or fake image
                            if(isset($_POST["submit"])) {
                                // $solution11 = $_POST['solution11'];  
                                // $solution12 = $_POST['solution12'];  
                                // $solution13 = $_POST['solution13'];  
                                // $solution14 = $_POST['solution14']; 
                            }

                            // Allow certain file formats
                            if($imageFileType != "pdf" &&  $imageFileType != "jpg" &&  $imageFileType != "pptx" && $imageFileType != "docx" && $imageFileType != "png" && $imageFileType != "jpeg"
                            && $imageFileType != "gif" ) {
                                echo "No upload Yet";
                                $uploadOk = 0;
                            }
                            // Check if $uploadOk is set to 0 by an error
                            if ($uploadOk == 0) {
                                echo " ";
                            // if everything is ok, try to upload file
                            } else {
                                if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
                                    $name = basename( $_FILES["fileToUpload"]["name"]) ;
                                    
                                    echo "The file $name has been uploaded.";
                                } else {
                                    echo "Sorry, there was an error uploading your file.";
                                }
}
?>