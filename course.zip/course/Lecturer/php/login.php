
<?php
require 'connect2db.php';

 session_start();
if(isset($_POST['username'])&&isset($_POST['password'])&&(!empty($_POST['username']))&&(!empty($_POST['password']))) 
	{
		$username = htmlentities($_POST['username']);
		$organisation = htmlentities($_POST['role']);
		$userentrypassword = htmlentities($_POST['password']);
				if ($organisation=="Lecturer")
				{				
				$query = "SELECT * FROM users WHERE username ='$username' and role ='Lecturer'" ;
					$result = mysqli_query($cxn,$query);
					$query_num_rows =  mysqli_num_rows($result);
					if ($query_num_rows==1) 
						{      $row = mysqli_fetch_assoc($result);
							   extract($row);
							   if ($userentrypassword == $row['password'])
									{		
										$_SESSION['username']= $username;
										$_SESSION['name']= $name;
									     header('Location:../HomePage.php');	
											
									} 
								else
								    {  $_SESSION['error'] ="watadza";
                                        header("location:../login.php?x=3");}
					    }
					else
						{   

                         $_SESSION['error'] ="watadza";
                         header("location:../login.php?x=3");
						}
		
							
				}
				elseif ($organisation=="Student")
				{				
				$query = "SELECT * FROM users WHERE username ='$username' and role = 'Student'" ;
					$result = mysqli_query($cxn,$query);
					$query_num_rows =  mysqli_num_rows($result);
					if ($query_num_rows==1) 
					{      $row = mysqli_fetch_assoc($result);
						   extract($row);
						   if ($userentrypassword == $row['password'])
								{		
									$_SESSION['username']= $username;
									$_SESSION['name']= $name;
									 header('Location:../HomePage.php');	
										
								} 
							else
								{  $_SESSION['error'] ="watadza";
									header("location:../login.php?x=3");}
					}
				else
					{   

					 $_SESSION['error'] ="watadza";
					 header("location:../login.php?x=3");
					}
							
				}
				elseif ($organisation=="Admin")
				{				
				$query = "SELECT * FROM users WHERE username ='$username' and role = 'Admin'" ;
					$result = mysqli_query($cxn,$query);
					$query_num_rows =  mysqli_num_rows($result);
					if ($query_num_rows==1) 
					{      $row = mysqli_fetch_assoc($result);
						   extract($row);
						   if ($userentrypassword == $row['password'])
								{		
									$_SESSION['username']= $username;
									$_SESSION['name']= $name;
									 header('Location:../HomePage.php');	
										
								} 
							else
								{  $_SESSION['error'] ="watadza";
									header("location:../login.php?x=3");}
					}
				else
					{   

					 $_SESSION['error'] ="watadza";
					 header("location:../login.php?x=3");
					}
							
				}
				
				 else {
				 header('Location:login.php?x=3');
				 }
	}
	
		
					 ?>