<?php
$mysqli_host= 'localhost';
$mysqli_user='root';
$mysqli_password='';
$mysqli_db='unischool';
$connection_error_message = "Ooop Couldn't connect to server";
$cxn = mysqli_connect($mysqli_host,$mysqli_user,$mysqli_password,$mysqli_db);
#or die ($connection_error_message)
?>
