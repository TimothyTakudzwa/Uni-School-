 <?php
                                    session_start();
                                        require 'connect2db.php';
                                     
                                        $message = mysqli_real_escape_string($cxn, $_POST['message']);
                                        $topic = mysqli_real_escape_string($cxn, $_POST['topic']);
                                        $subject = mysqli_real_escape_string($cxn, $_POST['subject']);
                                        $id = mysqli_real_escape_string($cxn, $_POST['id']);
                                        $name = $_SESSION['name'];
                                      
                                                                              
                                        $sql="INSERT INTO groupchat (text,name, chat_code, title,subject)
                                        VALUES ('$message', '$name', '$id', '$topic', '$subject')";
                                        $connection = mysqli_query($cxn, $sql);
                                        
                                          if (!mysqli_query($connection)) {
                                        header ("Location:../group.php?x=0&id=$id");}
                                          
                                ?>