<?php
$connection = mysqli_connect("localhost","root","","unischool")or die(mysqli_error($connection));

?>