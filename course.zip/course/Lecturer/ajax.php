<?php
require 'php/connect2db.php';
$id = $_GET['id'];
$sql = mysqli_query($cxn, "Select * from groupchat where chat_code =$id");



while($row=  mysqli_fetch_array($sql))

             {
                extract($row);
echo "<div class='itemdiv dialogdiv'>
<div class='user'>
    <img alt='Alexa's Avatar' src='assets/images/avatars/avatar5.png' />
</div>

<div class='body'>
    <div class='time'>
        <i class='ace-icon fa fa-clock-o'></i>
        <span class='green'>$time</span>
    </div>

    <div class='name'>
        <a href='#'>$name</a>
        
    </div>
    <div class='text'>$text</div>

    <div class='tools'>
        <a href='#' class='btn btn-minier btn-info'>
            <i class='icon-only ace-icon fa fa-share'></i>
        </a>
    </div>
</div>
</div>";
}?>