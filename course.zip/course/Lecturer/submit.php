<?php

$con=mysqli_connect("localhost","root","","unischool");
$id  = $_GET['id'];
$question1 = $_POST['question1'];  
$solution11 = $_POST['solution11'];  
$solution12 = $_POST['solution12'];  
$solution13 = $_POST['solution13'];  
$solution14 = $_POST['solution14'];  
$correct1 = $_POST['correct1']; 
$question2 = $_POST['question2'];  
$solution21 = $_POST['solution21'];  
$solution22 = $_POST['solution22'];  
$solution23 = $_POST['solution23'];  
$solution24 = $_POST['solution24'];  
$correct2 = $_POST['correct2']; 
$question3 = $_POST['question3'];  
$solution31 = $_POST['solution31'];  
$solution32 = $_POST['solution32'];  
$solution33 = $_POST['solution33'];  
$solution34 = $_POST['solution34'];  
$correct3= $_POST['correct3']; 
$question4 = $_POST['question4'];  
$solution41 = $_POST['solution41'];  
$solution42 = $_POST['solution42'];  
$solution43 = $_POST['solution43'];  
$solution44 = $_POST['solution44'];  
$correct4 = $_POST['correct4']; 
$question5 = $_POST['question5'];  
$solution51 = $_POST['solution51'];  
$solution52 = $_POST['solution52'];  
$solution53 = $_POST['solution53'];  
$solution54 = $_POST['solution54'];  
$correct5 = $_POST['correct5'];
$question6 = $_POST['question6'];  
$solution61 = $_POST['solution61'];  
$solution62 = $_POST['solution62'];  
$solution63 = $_POST['solution63'];  
$solution64 = $_POST['solution64'];  
$correct6= $_POST['correct6']; 
$question7 = $_POST['question7'];  
$solution71 = $_POST['solution71'];  
$solution72 = $_POST['solution72'];  
$solution73 = $_POST['solution73'];  
$solution74 = $_POST['solution74'];  
$correct7 = $_POST['correct7']; 
$question8 = $_POST['question8'];  
$solution81 = $_POST['solution81'];  
$solution82 = $_POST['solution82'];  
$solution83 = $_POST['solution83'];  
$solution84 = $_POST['solution84'];  
$correct8= $_POST['correct8']; 
$question9 = $_POST['question9'];  
$solution91 = $_POST['solution91'];  
$solution92 = $_POST['solution92'];  
$solution93 = $_POST['solution93'];  
$solution94 = $_POST['solution94'];  
$correct9= $_POST['correct9']; 
$question10 = $_POST['question10'];  
$solution101 = $_POST['solution101'];  
$solution102 = $_POST['solution102'];  
$solution103 = $_POST['solution103'];  
$solution104 = $_POST['solution104'];  
$correct10 = $_POST['correct10']; 
 //INSERT 
 $query = " INSERT INTO examination ( question,question_number, solution1, solution2, solution3, solution4, correct1, exam_code )
   VALUES   ( '$question1', '1','$solution11', '$solution12', '$solution13', '$solution14', '$correct1', '$id'),
   		     ('$question2', '2','$solution21', '$solution22', '$solution23', '$solution24', '$correct2', '$id'), 
			 ('$question3', '3','$solution31', '$solution32', '$solution33', '$solution34', '$correct3', '$id'),
			 ('$question4', '4','$solution41', '$solution42', '$solution43', '$solution44', '$correct4', '$id'),
			 ('$question5', '5','$solution51', '$solution52', '$solution53', '$solution54', '$correct5', '$id'),
			 ('$question6', '6','$solution61', '$solution62', '$solution63', '$solution64', '$correct6', '$id'),
   		     ('$question7', '7','$solution71', '$solution72', '$solution73', '$solution74', '$correct7', '$id'), 
			 ('$question8', '8','$solution81', '$solution82', '$solution83', '$solution84', '$correct8', '$id'),
			 ('$question9', '9','$solution91', '$solution92', '$solution93', '$solution94', '$correct9', '$id'),
			 ('$question10','10','$solution101', '$solution102', '$solution103', '$solution104', '$correct9', '$id') "; 
 $result = mysqli_query($con,$query); 

 if( $result )
 {
 	echo 'Success';
 }
 else
 {
 	echo 'Error: ' . mysqli_error($con);
 }

?>