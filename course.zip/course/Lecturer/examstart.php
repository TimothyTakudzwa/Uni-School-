<?php
$con=mysqli_connect("localhost","root","","unischool");
$name = $_POST['tutor'];  
$tittle = $_POST['tittle'];  
 
$duration = $_POST['duration']; 
$subject = $_POST['bookId']; 
$level = $_POST['level'];  
$type = $_POST['type'];
 
 error_reporting(null);
 //INSERT 
 $query = " INSERT INTO exams ( teacher,tittle, subject, duration, level, type)
   VALUES   ('$name','$tittle', '$subject', '$duration', '$level', '$type')
   		     
			  "; 
 $result = mysqli_query($con,$query); 
 $last_id = $con->insert_id;

 if( $result )
 {
	header("Location:exams.php?id=$last_id&title=$tittle&level=$level&subject=$subject&type=$type");
 }
 else
 {
 	echo 'Error: ' . mysqli_error($con); 
 }

?>