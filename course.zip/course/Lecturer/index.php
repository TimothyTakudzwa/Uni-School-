<!doctype html>
<?php  session_start(); if(!isset($_SESSION['username'])) { header('location:login.php');} ?>
<html lang="en"><head>
    
    <meta http-equiv="Content-Type" content="text/html;charset=utf-8" />
    
  
    
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
		<meta charset="utf-8" />
		<title>UniSchool | Lesson Plan</title>

		<meta name="description" content="with draggable and editable events" />
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0" />

		<!-- bootstrap & fontawesome -->
		<link rel="stylesheet" href="assets/css/bootstrap.min.css" />
		<link rel="stylesheet" href="assets/font-awesome/4.5.0/css/font-awesome.min.css" />

		<!-- page specific plugin styles -->
		<link rel="stylesheet" href="assets/css/jquery-ui.custom.min.css" />
		<link rel="stylesheet" href="assets/css/fullcalendar.min.css" />

		<!-- text fonts -->
		<link rel="stylesheet" href="assets/css/fonts.googleapis.com.css" />

		<!-- ace styles -->
		<link rel="stylesheet" href="assets/css/ace.min.css" class="ace-main-stylesheet" id="main-ace-style" />

		<!--[if lte IE 9]>
			<link rel="stylesheet" href="assets/css/ace-part2.min.css" class="ace-main-stylesheet" />
		<![endif]-->
		<link rel="stylesheet" href="assets/css/ace-skins.min.css" />
		<link rel="stylesheet" href="assets/css/ace-rtl.min.css" />

		<!--[if lte IE 9]>
		  <link rel="stylesheet" href="assets/css/ace-ie.min.css" />
		<![endif]-->

		<!-- inline styles related to this page -->

		<!-- ace settings handler -->
        <script src="assets/js/ace-extra.min.js"></script>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.4.0/fullcalendar.css" />
  
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.18.1/moment.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.4.0/fullcalendar.min.js"></script>
  <script>
   
  $(document).ready(function() {
   var calendar = $('#calendar').fullCalendar({
    editable:true,
    header:{
     left:'prev,next today',
     center:'title',
     right:'month,agendaWeek,agendaDay'
    },
    events: 'load.php',
    selectable:true,
    selectHelper:true,
    select: function(start, end, allDay)
    {
     var title = prompt("Enter Event Title");
     if(title)
     {
      var start = $.fullCalendar.formatDate(start, "Y-MM-DD HH:mm:ss");
      var end = $.fullCalendar.formatDate(end, "Y-MM-DD HH:mm:ss");
      $.ajax({
       url:"insert.php",
       type:"POST",
       data:{title:title, start:start, end:end},
       success:function()
       {
        calendar.fullCalendar('refetchEvents');
        alert("Added Successfully");
       }
      })
     }
    },
    editable:true,
    eventResize:function(event)
    {
     var start = $.fullCalendar.formatDate(event.start, "Y-MM-DD HH:mm:ss");
     var end = $.fullCalendar.formatDate(event.end, "Y-MM-DD HH:mm:ss");
     var title = event.title;
     var id = event.id;
     $.ajax({
      url:"update.php",
      type:"POST",
      data:{title:title, start:start, end:end, id:id},
      success:function(){
       calendar.fullCalendar('refetchEvents');
       alert('Event Update');
      }
     })
    },

    eventDrop:function(event)
    {
     var start = $.fullCalendar.formatDate(event.start, "Y-MM-DD HH:mm:ss");
     var end = $.fullCalendar.formatDate(event.end, "Y-MM-DD HH:mm:ss");
     var title = event.title;
     var id = event.id;
     $.ajax({
      url:"update.php",
      type:"POST",
      data:{title:title, start:start, end:end, id:id},
      success:function()
      {
       calendar.fullCalendar('refetchEvents');
       alert("Event Updated");
      }
     });
    },

    eventClick:function(event)
    {
     if(confirm("Are you sure you want to remove it?"))
     {
      var id = event.id;
      $.ajax({
       url:"delete.php",
       type:"POST",
       data:{id:id},
       success:function()
       {
        calendar.fullCalendar('refetchEvents');
        alert("Event Removed");
       }
      })
     }
    },

   });
  });
   
  </script>
  </head>
 <body class="no-skin">
    <div id="navbar" class="navbar navbar-default          ace-save-state">
        <div class="navbar-container ace-save-state" id="navbar-container">
            <button type="button" class="navbar-toggle menu-toggler pull-left" id="menu-toggler" data-target="#sidebar">
					<span class="sr-only">Toggle sidebar</span>

					<span class="icon-bar"></span>

					<span class="icon-bar"></span>

					<span class="icon-bar"></span>
				</button>

            <div class="navbar-header pull-left">
                <a href="index.html" class="navbar-brand">
                    <small>
							<i class="fa fa-globe"></i>
							UNI-SCHOOL
						</small>
                </a>
            </div>

            <div class="navbar-buttons navbar-header pull-right" role="navigation">
            <ul class="nav ace-nav">

                

                <li class="light-blue dropdown-modal">
                    <a data-toggle="dropdown" href="#" class="dropdown-toggle">
                        <img class="nav-user-photo" src="assets/images/avatars/avatar2.png" alt="Jason's Photo" />
                        <span class="user-info">
                                <small>Welcome,</small>
                                <?php								
                            echo "{$_SESSION['name']}"
                             ?>
                            </span>

                        <i class="ace-icon fa fa-caret-down"></i>
                    </a>

                    <ul class="user-menu dropdown-menu-right dropdown-menu dropdown-yellow dropdown-caret dropdown-close">
                        <li>
                            <a href="#">
                                <i class="ace-icon fa fa-cog"></i> Settings
                            </a>
                        </li>

                        <li>
                            <a href="profile.html">
                                <i class="ace-icon fa fa-user"></i> Profile
                            </a>
                        </li>

                        <li class="divider"></li>

                        <li>
                            <a href="php/logout.php">
                                <i class="ace-icon fa fa-power-off"></i> Logout
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        </div>
        </div>
        <!-- /.navbar-container -->
    </div>

    <div class="main-container ace-save-state" id="main-container">
        <script type="text/javascript">
            try {
                ace.settings.loadState('main-container')
            } catch (e) {}
        </script>

        <div id="sidebar" class="sidebar                  responsive                    ace-save-state">
           

            
            <!-- /.sidebar-shortcuts -->

            <ul class="nav nav-list">
            
                            <li class="">
                                <a href="HomePage.php">
                                    <i class="menu-icon fa fa-home"></i>
                                    <span class="menu-text"> HomePage </span>
                                </a>
            
                                <b class="arrow"></b>
                            </li>
                            <li class="">
                                <a href="examination.php">
                                    <i class="menu-icon fa fa-pencil-square-o"></i>
                                    <span class="menu-text"> Examination </span>
                                </a>
            
                                <b class="arrow"></b>
                            </li>
                            <li class="">
                                <a href="upload.php">
                                    <i class="menu-icon fa fa-list"></i>
                                    <span class="menu-text"> Subject Content </span>
                                </a>
            
                                <b class="arrow"></b>
                            </li>
                            <li class="">
                                <a href="groupchats.html">
                                    <i class="menu-icon fa fa-users"></i>
                                    <span class="menu-text"> Group Chats </span>
                                </a>
            
                                <b class="arrow"></b>
                            </li>
                            <li class="">
                                <a href="index.php">
                                    <i class="menu-icon fa fa-pencil"></i>
                                    <span class="menu-text"> Lesson Plan </span>
                                </a>
            
                                <b class="arrow"></b>
                            </li>
                            <li class="">
                                <a href="index.php">
                                    <i class="menu-icon fa fa-globe"></i>
                                    <span class="menu-text"> Case Studies </span>
                                </a>
            
                                <b class="arrow"></b>
                            </li>
                            <li class="">
                                <a href="profile.html">
                                    <i class="menu-icon fa fa-user"></i>
                                    <span class="menu-text"> Profile </span>
                                </a>
            
                                <b class="arrow"></b>
                            </li>
            
            
            
            
            
            
            
                        </ul>
            <!-- /.nav-list -->

            <div class="sidebar-toggle sidebar-collapse" id="sidebar-collapse">
                <i id="sidebar-toggle-icon" class="ace-icon fa fa-angle-double-left ace-save-state" data-icon1="ace-icon fa fa-angle-double-left" data-icon2="ace-icon fa fa-angle-double-right"></i>
            </div>
        </div>

        

               
                   
                    <!-- /.breadcrumb -->

                    <div class="nav-search" id="nav-search">
                        <form class="form-search">

                        </form>
                    </div>
                    <!-- /.nav-search -->
               
  <div class="page-header">
                        <h1>
                            Lesson Plan
                            <small>
									<i class="ace-icon fa fa-angle-double-right"></i>
									Select Date and Time and create Lesson Plan
								</small>
								<button class="btn btn-primary"> Lesson Notes & Content </button><small>Or View</small><a href="feedback.php"><button class="btn btn-success"> Student Lesson Feedback </button></a>
                        </h1>
						
                    </div>
        
    
                    <br />
  <h2 align="center"><a href="#">Create Your Own Lesson Plan here</a></h2>
  <br />
  <div class="container">
   <div id="calendar"></div>
  </div>
	

  </body>
</html>