<!DOCTYPE html>
<html lang="en">
<?php  session_start(); if(!isset($_SESSION['username'])) { header('location:login.php');} ?>
<head>
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <meta charset="utf-8" />
    <title>UNI-SCHOOL | Examinations</title>
    <link href="//netdna.bootstrapcdn.com/bootstrap/3.0.3/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <script src="//netdna.bootstrapcdn.com/bootstrap/3.0.3/js/bootstrap.min.js"></script>
    <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
    <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
    <meta name="description" content="" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0" />
<style>
form_main {
    width: 100%;
}
.form_main h4 {
    font-family: roboto;
    font-size: 20px;
    font-weight: 300;
    margin-bottom: 15px;
    margin-top: 20px;
    text-transform: uppercase;
}
.heading {
    border-bottom: 1px solid #fcab0e;
    padding-bottom: 9px;
    position: relative;
}
.heading span {
    background: #9e6600 none repeat scroll 0 0;
    bottom: -2px;
    height: 3px;
    left: 0;
    position: absolute;
    width: 75px;
}   
.form {
    border-radius: 7px;
    padding: 6px;
}
.txt[type="text"] {
    border: 1px solid #ccc;
    margin: 10px 0;
    padding: 10px 0 10px 5px;
    width: 100%;
}
.txt_3[type="text"] {
    margin: 10px 0 0;
    padding: 10px 0 10px 5px;
    width: 100%;
}
.txt2[type="submit"] {
    background: #242424 none repeat scroll 0 0;
    border: 1px solid #4f5c04;
    border-radius: 25px;
    color: #fff;
    font-size: 16px;
    font-style: normal;
    line-height: 35px;
    margin: 10px 0;
    padding: 0;
    text-transform: uppercase;
    width: 30%;
}
.txt2:hover {
    background: rgba(0, 0, 0, 0) none repeat scroll 0 0;
    color: #5793ef;
    transition: all 0.5s ease 0s;
}

</style>
    <!-- bootstrap & fontawesome -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css" />
    <link rel="stylesheet" href="assets/font-awesome/4.5.0/css/font-awesome.min.css" />

    <!-- page specific plugin styles -->

    <!-- text fonts -->
    <link rel="stylesheet" href="assets/css/fonts.googleapis.com.css" />

    <!-- ace styles -->
    <link rel="stylesheet" href="assets/css/ace.min.css" class="ace-main-stylesheet" id="main-ace-style" />

    <!--[if lte IE 9]>
			<link rel="stylesheet" href="assets/css/ace-part2.min.css" class="ace-main-stylesheet" />
		<![endif]-->
    <link rel="stylesheet" href="assets/css/ace-skins.min.css" />
    <link rel="stylesheet" href="assets/css/ace-rtl.min.css" />

    <!--[if lte IE 9]>
		  <link rel="stylesheet" href="assets/css/ace-ie.min.css" />
		<![endif]-->

    <!-- inline styles related to this page -->

    <!-- ace settings handler -->
    <script src="assets/js/ace-extra.min.js"></script>

    <!-- HTML5shiv and Respond.js for IE8 to support HTML5 elements and media queries -->

    <!--[if lte IE 8]>
		<script src="assets/js/html5shiv.min.js"></script>
		<script src="assets/js/respond.min.js"></script>
		<![endif]-->
</head>

<body class="no-skin">
    <div id="navbar" class="navbar navbar-default          ace-save-state">
        <div class="navbar-container ace-save-state" id="navbar-container">
            <button type="button" class="navbar-toggle menu-toggler pull-left" id="menu-toggler" data-target="#sidebar">
					<span class="sr-only">Toggle sidebar</span>

					<span class="icon-bar"></span>

					<span class="icon-bar"></span>

					<span class="icon-bar"></span>
				</button>

            <div class="navbar-header pull-left">
                <a href="index.html" class="navbar-brand">
                    <small>
							<i class="fa fa-globe"></i>
							UNI-SCHOOL
						</small>
                </a>
            </div>

            <div class="navbar-buttons navbar-header pull-right" role="navigation">
            <ul class="nav ace-nav">

                

                <li class="light-blue dropdown-modal">
                    <a data-toggle="dropdown" href="#" class="dropdown-toggle">
                        <img class="nav-user-photo" src="assets/images/avatars/avatar2.png" alt="Jason's Photo" />
                        <span class="user-info">
                                <small>Welcome,</small>
                                <?php echo "{$_SESSION['name']}"  ?>
                            </span>

                        <i class="ace-icon fa fa-caret-down"></i>
                    </a>

                    <ul class="user-menu dropdown-menu-right dropdown-menu dropdown-yellow dropdown-caret dropdown-close">
                        <li>
                            <a href="#">
                                <i class="ace-icon fa fa-cog"></i> Settings
                            </a>
                        </li>

                        <li>
                            <a href="profile.html">
                                <i class="ace-icon fa fa-user"></i> Profile
                            </a>
                        </li>

                        <li class="divider"></li>

                        <li>
                            <a href="php/logout.php">
                                <i class="ace-icon fa fa-power-off"></i> Logout
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        </div>
        </div>
        <!-- /.navbar-container -->
    </div>

    <div class="main-container ace-save-state" id="main-container">
        <script type="text/javascript">
            try {
                ace.settings.loadState('main-container')
            } catch (e) {}
        </script>

        <div id="sidebar" class="sidebar                  responsive                    ace-save-state">
            <script type="text/javascript">
                try {
                    ace.settings.loadState('sidebar')
                } catch (e) {}
            </script>

            <div class="sidebar-shortcuts" id="sidebar-shortcuts">

                <div class="sidebar-shortcuts-mini" id="sidebar-shortcuts-mini">

                    <span class="btn btn-danger"></span>
                </div>
            </div>
            <!-- /.sidebar-shortcuts -->

            <ul class="nav nav-list">
            
                            <li class="">
                                <a href="HomePage.php">
                                    <i class="menu-icon fa fa-home"></i>
                                    <span class="menu-text"> HomePage </span>
                                </a>
            
                                <b class="arrow"></b>
                            </li>
                            <li class="">
                                <a href="examination.php">
                                    <i class="menu-icon fa fa-pencil-square-o"></i>
                                    <span class="menu-text"> Examination </span>
                                </a>
            
                                <b class="arrow"></b>
                            </li>
                            <li class="">
                                <a href="upload.php">
                                    <i class="menu-icon fa fa-list"></i>
                                    <span class="menu-text"> Subject Content </span>
                                </a>
            
                                <b class="arrow"></b>
                            </li>
                            <li class="">
                                <a href="groupchats.php">
                                    <i class="menu-icon fa fa-users"></i>
                                    <span class="menu-text"> Group Chats </span>
                                </a>
            
                                <b class="arrow"></b>
                            </li>
                            <li class="">
                                <a href="index.php">
                                    <i class="menu-icon fa fa-pencil"></i>
                                    <span class="menu-text"> Lesson Plan </span>
                                </a>
            
                                <b class="arrow"></b>
                            </li>
                            <li class="">
                                <a href="index.php">
                                    <i class="menu-icon fa fa-globe"></i>
                                    <span class="menu-text"> Case Studies </span>
                                </a>
            
                                <b class="arrow"></b>
                            </li>
                            <li class="">
                                <a href="profile.html">
                                    <i class="menu-icon fa fa-user"></i>
                                    <span class="menu-text"> Profile </span>
                                </a>
            
                                <b class="arrow"></b>
                            </li>
            
            
            
            
            
            
            
                        </ul>
            <!-- /.nav-list -->

            <div class="sidebar-toggle sidebar-collapse" id="sidebar-collapse">
                <i id="sidebar-toggle-icon" class="ace-icon fa fa-angle-double-left ace-save-state" data-icon1="ace-icon fa fa-angle-double-left" data-icon2="ace-icon fa fa-angle-double-right"></i>
            </div>
        </div>

        <div class="main-content">
            <div class="main-content-inner">
                <div class="breadcrumbs ace-save-state" id="breadcrumbs">
                    <ul class="breadcrumb">
                        <li>
                            <i class="ace-icon fa fa-home home-icon"></i>
                            <a href="#">Home</a>
                        </li>

                        <li>
                            <a href="#">HomePage</a>
                        </li>

                    </ul>
                    <!-- /.breadcrumb -->

                    <div class="nav-search" id="nav-search">
                        <form class="form-search">
                            <span class="input-icon">
									<input type="text" placeholder="Search ..." class="nav-search-input" id="nav-search-input" autocomplete="off" />
									<i class="ace-icon fa fa-search nav-search-icon"></i>
								</span>
                        </form>
                    </div>
                    <!-- /.nav-search -->
                </div>

                <div class="page-content">
                    <div class="ace-settings-container" id="ace-settings-container">
                        <div class="btn btn-app btn-xs btn-warning ace-settings-btn" id="ace-settings-btn">
                            <i class="ace-icon fa fa-cog bigger-130"></i>
                        </div>

                        <div class="ace-settings-box clearfix" id="ace-settings-box">
                            <div class="pull-left width-50">
                                <div class="ace-settings-item">
                                    <div class="pull-left">
                                        <select id="skin-colorpicker" class="hide">
												<option data-skin="no-skin" value="#438EB9">#438EB9</option>
												<option data-skin="skin-1" value="#222A2D">#222A2D</option>
												<option data-skin="skin-2" value="#C6487E">#C6487E</option>
												<option data-skin="skin-3" value="#D0D0D0">#D0D0D0</option>
											</select>
                                    </div>
                                    <span>&nbsp; Choose Skin</span>
                                </div>

                                <div class="ace-settings-item">
                                    <input type="checkbox" class="ace ace-checkbox-2 ace-save-state" id="ace-settings-navbar" autocomplete="off" />
                                    <label class="lbl" for="ace-settings-navbar"> Fixed Navbar</label>
                                </div>

                                <div class="ace-settings-item">
                                    <input type="checkbox" class="ace ace-checkbox-2 ace-save-state" id="ace-settings-sidebar" autocomplete="off" />
                                    <label class="lbl" for="ace-settings-sidebar"> Fixed Sidebar</label>
                                </div>

                                <div class="ace-settings-item">
                                    <input type="checkbox" class="ace ace-checkbox-2 ace-save-state" id="ace-settings-breadcrumbs" autocomplete="off" />
                                    <label class="lbl" for="ace-settings-breadcrumbs"> Fixed Breadcrumbs</label>
                                </div>

                                <div class="ace-settings-item">
                                    <input type="checkbox" class="ace ace-checkbox-2" id="ace-settings-rtl" autocomplete="off" />
                                    <label class="lbl" for="ace-settings-rtl"> Right To Left (rtl)</label>
                                </div>

                                <div class="ace-settings-item">
                                    <input type="checkbox" class="ace ace-checkbox-2 ace-save-state" id="ace-settings-add-container" autocomplete="off" />
                                    <label class="lbl" for="ace-settings-add-container">
											Inside
											<b>.container</b>
										</label>
                                </div>
                            </div>
                            <!-- /.pull-left -->

                            <div class="pull-left width-50">
                                <div class="ace-settings-item">
                                    <input type="checkbox" class="ace ace-checkbox-2" id="ace-settings-hover" autocomplete="off" />
                                    <label class="lbl" for="ace-settings-hover"> Submenu on Hover</label>
                                </div>

                                <div class="ace-settings-item">
                                    <input type="checkbox" class="ace ace-checkbox-2" id="ace-settings-compact" autocomplete="off" />
                                    <label class="lbl" for="ace-settings-compact"> Compact Sidebar</label>
                                </div>

                                <div class="ace-settings-item">
                                    <input type="checkbox" class="ace ace-checkbox-2" id="ace-settings-highlight" autocomplete="off" />
                                    <label class="lbl" for="ace-settings-highlight"> Alt. Active Item</label>
                                </div>
                            </div>
                            <!-- /.pull-left -->
                        </div>
                        <!-- /.ace-settings-box -->
                    </div>
                    <!-- /.ace-settings-container -->

                    <div class="row">
                        <div class="col-xs-9">
                            <!-- PAGE CONTENT BEGINS -->
<div class="container">
	<div class="page-header">
                        <h1>
                            Examinations
                            <small>
									<i class="ace-icon fa fa-angle-double-right"></i>
									Select Subject to set exam proceed
								</small>
                        </h1>
                    </div>
    <div class="row">
       
        <div class="col-xs-9">
            <div class="panel panel-info">
                <div class="panel-heading">
                    <h3 class="panel-title">
                        List of All Subjects</h3>
                </div>
                <ul class="list-group">
					<div class="container">
	<div class="row">
		


	</div>
</div>
                    <a href="#exampleModal" class="list-group-item " data-toggle="modal" data-book-id="Mathematics" >Mathematics</a>
                    <a href="#" class="list-group-item "data-toggle="modal" data-target="#exampleModal" data-book-id="English" >English</a>
                    <a href="#" class="list-group-item"data-toggle="modal" data-target="#exampleModal" data-book-id="Shona" >Shona</a>
                    <a href="#" class="list-group-item"data-toggle="modal" data-target="#exampleModal" data-book-id="Integrated Science" >Integrated Science</a>
					<a href="#" class="list-group-item"data-toggle="modal" data-target="#exampleModal" data-book-id="Physical Science" >Physical Science</a>
					<a href="#" class="list-group-item" data-toggle="modal" data-target="#exampleModal" data-book-id="Physics" >Physics</a>
                    <a href="#" class="list-group-item" data-toggle="modal" data-target="#exampleModal" data-book-id="Biology" >Biology</a>
                    <a href="#" class="list-group-item" data-toggle="modal" data-target="#exampleModal" data-book-id="Chemistry" >Chemistry</a>
                    <a href="#" class="list-group-item" data-toggle="modal" data-target="#exampleModal" data-book-id="Further Mathematics" >Further Mathematics</a>
					<a href="#" class="list-group-item"data-toggle="modal" data-target="#exampleModal" data-book-id="Geography" >Geography</a>
					<a href="#" class="list-group-item"data-toggle="modal" data-target="#exampleModal" data-book-id="History" >History</a>
                    <a href="#" class="list-group-item"data-toggle="modal" data-target="#exampleModal" data-book-id="Literature" >Literature</a>
                    <a href="#" class="list-group-item"data-toggle="modal" data-target="#exampleModal" data-book-id="Divinity" >Divinity</a>
                    <a href="#" class="list-group-item"data-toggle="modal" data-target="#exampleModal" data-book-id="Commerce" >Commerce</a>
					<a href="#" class="list-group-item"data-toggle="modal" data-target="#exampleModal" data-book-id="Accounting" >Accounting</a>
					<a href="#" class="list-group-item"data-toggle="modal" data-target="#exampleModal" data-book-id="Computing" >Computing</a>
                    <a href="#" class="list-group-item"data-toggle="modal" data-target="#exampleModal" data-book-id="Fashion and Fabrics" >Fashion and Fabrics</a>
                    <a href="#" class="list-group-item"data-toggle="modal" data-target="#exampleModal" data-book-id="Food and Nutrition" >Food and Nutrition</a>
                    <a href="#" class="list-group-item"data-toggle="modal" data-target="#exampleModal" data-book-id="Building" >Building</a>
					<a href="#" class="list-group-item"data-toggle="modal" data-target="#exampleModal" data-book-id="Metal Work" >Metal Work</a>
					<a href="#" class="list-group-item"data-toggle="modal" data-target="#exampleModal" data-book-id="Business Studies " >Business Studies</a>
                    <a href="#" class="list-group-item"data-toggle="modal" data-target="#exampleModal" data-book-id="Wood Work" >Wood Work</a>
                    <a href="#" class="list-group-item"data-toggle="modal" data-target="#exampleModal" data-book-id="Economics" >Economics</a>
                    <a href="#" class="list-group-item"data-toggle="modal" data-target="#exampleModal" data-book-id="Agriculture" >Agriculture</a>
                    <a href="#" class="list-group-item"data-toggle="modal" data-target="#exampleModal" data-book-id="Horticulture" >Horticulture</a>
                    
                </ul>
            </div>
        </div>
       
    </div>
</div>
                            <!-- PAGE CONTENT ENDS -->
                        </div>
                        <!-- /.col -->
                    </div>
                    <!-- /.row -->
                </div>
                <!-- /.page-content -->
            </div>
        </div>
        <!-- /.main-content -->

        <div class="footer">
            <div class="footer-inner">
                <div class="footer-content">
                    <span class="bigger-120">
							<span class="blue bolder">Explorer Development</span> Application &copy; 2018
                    </span>

                    &nbsp; &nbsp;
                    <span class="action-buttons">
							<a href="#">
								<i class="ace-icon fa fa-twitter-square light-blue bigger-150"></i>
							</a>

							<a href="#">
								<i class="ace-icon fa fa-facebook-square text-primary bigger-150"></i>
							</a>

							<a href="#">
								<i class="ace-icon fa fa-rss-square orange bigger-150"></i>
							</a>
						</span>
                </div>
            </div>
        </div>

        <a href="#" id="btn-scroll-up" class="btn-scroll-up btn btn-sm btn-inverse">
            <i class="ace-icon fa fa-angle-double-up icon-only bigger-110"></i>
        </a>
    </div>
    
    <!-- /.main-container -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
        <div class="form_main">
            <h4 class="heading"><strong>Examination </strong> Settings <span></span></h4>
            <div class="form">
            <form action="examstart.php" method="post" id="contactFrm" name="contactFrm">
                 <label for="recipient-name" class="control-label">Subject:</label>
                <input type="text"  placeholder="Please input your Name"  name="bookId" class="txt">
                <label for="recipient-name" class="control-label">Teacher:</label>
                <input type="text"   value="<?php echo "{$_SESSION['name']}" ?>" name="tutor" class="txt">
                <label for="recipient-name" class="control-label">Duration: </label><br />
                <input type="number"  placeholder="Duration in Minutes" name="duration" class="txt">    <br />    
                <label for="message-text" class="control-label">Select Level:</label>
                
                        <select name="level" class="chosen-select form-control" id="form-field-select-3" data-placeholder="Choose a State...">						
                            <option value="ZJC">Zimbabwe Junior Certificate</option>
                            <option value="O">Ordinary Level</option>
                            <option value="A">Advanced Level</option>
                            
                        </select>
                        <label for="message-text" class="control-label">Exam Type:</label>                
                         
                                <select name="type" class="chosen-select form-control" id="form-field-select-3" data-placeholder="Choose a State...">						
                                    <option value="Quiz">Quiz</option>
                                    <option value="Homework">Homework</option>
                                    <option value="Test">Test</option>
                                    <option value="Final Exam">Final</option>
                                    <option value="Other">Other</option>
                                </select> 
                                <label for="recipient-name" class="control-label">Exam Title:</label>
                                <input type="text"  placeholder="Test 1 / Quiz 1 /...." name="tittle" class="txt">
                                <label for="message-text" class="control-label">Select Action:</label>
                                
                                        <select class="chosen-select form-control" id="form-field-select-3" data-placeholder="Choose a State...">
                                            
                                            <option value="ZJC">View All Exams</option>
                                            <option value="O">Create Exam</option>	
                                            
                                        </select>       
         
        </div>
        </div>
    
    <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
       
        <input type="submit" class="btn btn-primary"></button>
        </form>
      </div>
      </div>
    </div>
  </div>
</div>
    <!-- basic scripts -->

    <!--[if !IE]> -->
    <script src="assets/js/jquery-2.1.4.min.js"></script>

    <!-- <![endif]-->

    <!--[if IE]>
<script src="assets/js/jquery-1.11.3.min.js"></script>
<![endif]-->
	<script type="text/javascript">
    $('#exampleModal').on('show.bs.modal', function(e) {
    var bookId = $(e.relatedTarget).data('book-id');
    $(e.currentTarget).find('input[name="bookId"]').val(bookId);
});
  </script>

  
    <script src="assets/js/bootstrap.min.js"></script>

    <!-- page specific plugin scripts -->

    <!-- ace scripts -->
    <script src="assets/js/ace-elements.min.js"></script>
    <script src="assets/js/ace.min.js"></script>

    <!-- inline scripts related to this page -->
</body>

</html>